export default function Contact() {
  return (
    <main>
      <h1>Contact</h1>
      <p>Email: contact@akashrealestate.com</p>
    </main>
  );
}