export default function About() {
  return (
    <main>
      <h1>About Us</h1>
      <p>We provide premium real estate services.</p>
    </main>
  );
}