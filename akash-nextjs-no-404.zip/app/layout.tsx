export const metadata = {
  title: "Akash Real Estate",
  description: "Premium Real Estate Website"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
        <nav style={{ marginBottom: "20px" }}>
          <a href="/">Home</a> | <a href="/about">About</a> | <a href="/contact">Contact</a>
        </nav>
        {children}
      </body>
    </html>
  );
}