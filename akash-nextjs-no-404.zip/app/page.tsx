export default function Home() {
  return (
    <main>
      <h1>🏡 Welcome to Akash Real Estate</h1>
      <p>Find your dream property with us.</p>
    </main>
  );
}